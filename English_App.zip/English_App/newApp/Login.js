import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ImageBackground, Alert } from 'react-native';
import { signInWithEmailAndPassword } from 'firebase/auth';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { auth } from './firebaseConfig'; 

const Login = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  useEffect(() => {
    const retrieveUserData = async () => {
      try {
        // AsyncStorage'den kaydedilmiş email ve şifreyi al
        const savedEmail = await AsyncStorage.getItem('email');
        const savedPassword = await AsyncStorage.getItem('password');
  
        // Eğer kaydedilmiş email ve şifre varsa, state'e ayarla
        if (savedEmail && savedPassword) {
          setEmail(savedEmail);
          setPassword(savedPassword);
        }
      } catch (error) {
        console.error('Bilgileri alma hatası:', error);
      }
    };
  
    // Component yüklendiğinde çağrılacak olan retrieveUserData fonksiyonunu çağır
    retrieveUserData();
  }, []);
  
  
  // Kullanıcı çıkış yap butonuna tıkladığında AsyncStorage'den token'ı temizle ve login sayfasına yönlendir
  const handleLogout = () => {
    AsyncStorage.removeItem('token')
      .then(() => {
        navigation.navigate('Login');
      })
      .catch((error) => {
        console.error('Token silme hatası:', error);
      });
  };
  
  
  

  const handleLogin = () => {
    signInWithEmailAndPassword(auth, email, password)
      .then((userCredential) => {
        const user = userCredential.user;
        // Giriş başarılı olduğunda AsyncStorage'de kullanıcı bilgilerini ve tokenı kaydet
        AsyncStorage.setItem('email', email);
        AsyncStorage.setItem('password', password);
        AsyncStorage.setItem('token', user.accessToken);
        // AnaEkran'a yönlendir
        navigation.reset({
          index: 0,
          routes: [{ name: 'AnaEkran' }],
        });
      })
      .catch((error) => {
        Alert.alert('Giriş Başarısız', error.message);
      });
  };

  return (
    <ImageBackground
      source={{ uri: 'https://img.kwcdn.com/product/Fancyalgo/VirtualModelMatting/163cfe899be82d558acd389aeea86b9f.jpg?imageMogr2/auto-orient%7CimageView2/2/w/800/q/70/format/webp' }}
      style={styles.background}
    >
      <View style={styles.overlay} />
      <View style={styles.container}>
        <Text style={styles.title}>Giriş Yap</Text>
        <TextInput
          style={styles.input}
          placeholder="Email"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          placeholderTextColor="#ccc"
        />
        <TextInput
          style={styles.input}
          placeholder="Şifre"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
          placeholderTextColor="#ccc"
        />
        <TouchableOpacity style={styles.button} onPress={handleLogin}>
          <Text style={styles.buttonText}>Giriş Yap</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Signup')}>
          <Text style={styles.switchText}>Hesabın yok mu? Kayıt ol</Text>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    justifyContent: 'center',
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 32,
    marginBottom: 20,
    color: '#fff',
    fontWeight: 'bold',
  },
  input: {
    width: '100%',
    padding: 15,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    color: '#333',
  },
  button: {
    backgroundColor: '#28a745',
    padding: 15,
    width: '100%',
    alignItems: 'center',
    borderRadius: 5,
    marginBottom: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  switchText: {
    color: '#007BFF',
    marginTop: 20,
  },
});

export default Login;
