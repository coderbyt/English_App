import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ImageBackground } from 'react-native';
import { database } from './firebaseConfig';
import { ref, onValue, off } from 'firebase/database';

const Oyun = ({ route }) => {
  const { kategori } = route.params;
  const [currentWord, setCurrentWord] = useState('');
  const [correctAnswer, setCorrectAnswer] = useState('');
  const [incorrectAnswer, setIncorrectAnswer] = useState('');
  const [dogruSayisi, setDogruSayisi] = useState(0);
  const [yanlisSayisi, setYanlisSayisi] = useState(0);
  const [kategoriKelimeler, setKategoriKelimeler] = useState('');
  const [feedback, setFeedback] = useState('');

  useEffect(() => {
    const kategoriRef = ref(database, 'kategoriler/' + kategori);
    onValue(kategoriRef, (snapshot) => {
      const kelimeler = snapshot.val();
      const kategoriKelimeler = Object.values(kelimeler);
      if (kategoriKelimeler.length > 0) {
        setKategoriKelimeler(kategoriKelimeler);
        selectRandomWord(kategoriKelimeler);
      } else {
        alert('Bu kategoriye ait kelime bulunamadı.');
      }
    });

    return () => {
      // Cleanup function to remove the listener when component unmounts
      off(kategoriRef);
    };
  }, [kategori]);

  const selectRandomWord = (kategoriKelimeler) => {
    const randomIndex = Math.floor(Math.random() * kategoriKelimeler.length);
    const selectedWord = kategoriKelimeler[randomIndex];
    setCurrentWord(selectedWord.kelime.toUpperCase());
    setCorrectAnswer(selectedWord.anlam.toUpperCase());

    const randomIncorrectWord = getRandomIncorrectWord(kategoriKelimeler, selectedWord.anlam);
    setIncorrectAnswer(randomIncorrectWord.toUpperCase());
  };

  const getRandomIncorrectWord = (kelimeler, correctAnswer) => {
    let incorrectWord;
    do {
      const randomIndex = Math.floor(Math.random() * kelimeler.length);
      incorrectWord = kelimeler[randomIndex].anlam;
    } while (incorrectWord === correctAnswer);
    return incorrectWord;
  };
  const checkAnswer = (answer) => {
    if (answer === correctAnswer) {
      setFeedback('Doğru cevap!');
      setDogruSayisi(dogruSayisi + 1);
    } else {
      setFeedback(<Text style={{ color: 'red' }}>Yanlış cevap!</Text>);
      setYanlisSayisi(yanlisSayisi + 1);
    }
    setTimeout(() => {
      setFeedback('');
      selectRandomWord(kategoriKelimeler);
    }, 1000);
  };
  
  const skipWord = () => {
    selectRandomWord(kategoriKelimeler);
  };

  return (
    <ImageBackground source={{ uri: 'https://images.pexels.com/photos/5428833/pexels-photo-5428833.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500' }} style={styles.background}>
      <View style={styles.container}>
        <TouchableOpacity
          style={styles.wordButton}
          onPress={() => checkAnswer(correctAnswer)}
        >
          <Text style={styles.word}>{currentWord}</Text>
        </TouchableOpacity>
        <Text style={styles.feedback}>{feedback}</Text>
        <View style={styles.buttonContainer}>
          <TouchableOpacity
            style={styles.button}
            onPress={() => checkAnswer(correctAnswer)}
          >
            <Text style={styles.buttonText}>{correctAnswer}</Text>
          </TouchableOpacity>
          <View style={styles.buttonSpacer} />
          <TouchableOpacity
            style={styles.button}
            onPress={() => checkAnswer(incorrectAnswer)}
          >
            <Text style={styles.buttonText}>{incorrectAnswer}</Text>
          </TouchableOpacity>
        </View>
        <TouchableOpacity
          style={styles.skipButton}
          onPress={skipWord}
        >
          <Text style={styles.skipText}> Geç </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.scoreButton}
          onPress={() => {}}
        >
          <Text style={styles.scoreText}>Doğru: {dogruSayisi} - Yanlış: {yanlisSayisi}</Text>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: "cover",
    justifyContent: "center"
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  wordButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    padding: 15,
    borderRadius: 10,
    marginBottom: 20,
  },
  word: {
    fontSize: 40,
    textTransform: 'uppercase',
    textAlign: 'center',
  },
  feedback: {
    fontSize: 20,
    marginBottom: 40,
    color: 'green',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 40,
  },
  button: {
    alignItems: 'center',
    padding: 15,
    borderRadius: 50,
    width: 150,
    backgroundColor: '#DDDDDD',
  },
  buttonText: {
    fontSize: 18,
  },
  buttonSpacer: {
    marginRight: 15,
  },
  skipButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    padding: 10,
    borderRadius: 10,
    marginBottom: 100,
  },
  skipText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  scoreButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    padding: 15,
    borderRadius: 10,
  },
  scoreText: {
    fontSize: 18,
  },
});

export default Oyun;
