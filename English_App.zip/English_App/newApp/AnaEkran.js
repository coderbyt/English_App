import React, { useState, useEffect } from 'react';
import { View, StyleSheet, TouchableOpacity, Text, ImageBackground } from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import CustomButton from './Butonlar';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { database } from './firebaseConfig';
import { ref, onValue } from 'firebase/database';
import { CommonActions } from '@react-navigation/native';

const AnaEkran = ({ navigation }) => {
  const [menuVisible, setMenuVisible] = useState(false);
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    const kategoriRef = ref(database, 'kategoriler');
    const unsubscribe = onValue(kategoriRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        setCategories(Object.keys(data));
      }
    }, (error) => {
      console.error('Firebase hata:', error);
    });

    return () => unsubscribe();
  }, []);


  const kategoriyeGit = (kategori) => {
    navigation.navigate('Oyun', { kategori });
  };

  const toggleMenu = () => {
    setMenuVisible(!menuVisible);
  };

  const handleLogout = async () => {
    try {
      await AsyncStorage.multiRemove(['token', 'email', 'password']);
      console.log('Bilgiler başarıyla silindi.');
      navigation.reset({
        index: 0,
        routes: [{ name: 'Login' }],
      });
    } catch (error) {
      console.error('Bilgi silme hatası:', error);
    }
  };
  
  

  const goToProfile = () => {
    navigation.dispatch(
      CommonActions.navigate({
        name: 'Profil',
      })
    );
  };

  const navigateToKelimeEkle = () => {
    navigation.navigate('KelimeEkle');
  };

  const backToLogin = () => {
    navigation.navigate('Login');
  };

  return (
    <ImageBackground source={{ uri: 'https://images.pexels.com/photos/5428833/pexels-photo-5428833.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500' }} style={styles.background}>
      <View style={styles.container}>
        <TouchableOpacity style={styles.menuButton} onPress={toggleMenu}>
          <MaterialCommunityIcons name="menu" size={24} color="black" />
        </TouchableOpacity>
        {menuVisible && (
          <View style={styles.menu}>
            <TouchableOpacity style={styles.menuItem} onPress={goToProfile}>
              <Text style={styles.menuText}>Profilim</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.menuItem} onPress={handleLogout}>
              <Text style={styles.menuText}>Çıkış Yap</Text>
            </TouchableOpacity>
          </View>
        )}
        {categories.map((kategori) => (
          <CustomButton
            key={kategori}
            onPress={() => kategoriyeGit(kategori)}
            title={kategori.toUpperCase()}
            icon="format-color-fill"
            iconPosition="left"
          />
        ))}
        <TouchableOpacity style={styles.kelimeEkleButton} onPress={navigateToKelimeEkle}>
          <Text style={styles.kelimeEkleText}>Kelime Ekle</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.backButton} onPress={backToLogin}>
          <Text style={styles.backButtonText}>Çıkış Yap</Text>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: "cover",
    justifyContent: "center"
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  menuButton: {
    position: 'absolute',
    bottom: 20,
    right: 20,
    zIndex: 1, // Menü butonunun diğer bileşenlerin önünde olmasını sağlar
  },
  menu: {
    position: 'absolute',
    bottom: 80,
    right: 20,
    backgroundColor: '#fff',
    borderRadius: 5,
    padding: 10,
    elevation: 3,
  },
  menuItem: {
    padding: 10,
  },
  menuText: {
    fontSize: 16,
  },
  kelimeEkleButton: {
    marginTop: 60,
    backgroundColor: '#ff6347',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 20,
  },
  kelimeEkleText: {
    color: '#fff',
    fontSize: 18,
  },
  backButton: {
    marginTop: 20,
    backgroundColor: '#4682B4',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 20,
  },
  backButtonText: {
    color: '#fff',
    fontSize: 18,
  },
});

export default AnaEkran;
