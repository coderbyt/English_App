// firebaseConfig.js
import { initializeApp } from 'firebase/app';
import { getAnalytics } from 'firebase/analytics';
import { getAuth } from 'firebase/auth';
import { getDatabase } from 'firebase/database';

const firebaseConfig = {
  apiKey: "AIzaSyAlWEqYuqG3dVxX3PqrSa5eahUI8nhi60g",
  authDomain: "englishapp-5cb36.firebaseapp.com",
  databaseURL: "https://englishapp-5cb36-default-rtdb.firebaseio.com",
  projectId: "englishapp-5cb36",
  storageBucket: "englishapp-5cb36.appspot.com",
  messagingSenderId: "36567138947",
  appId: "1:36567138947:web:e6367c96ef2583a107d1b6",
  measurementId: "G-0563LD6JHB"
};

// Firebase'i başlat
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const auth = getAuth(app);
const database = getDatabase(app);

export { app, analytics, auth, database };
