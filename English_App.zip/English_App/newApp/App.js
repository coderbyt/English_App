import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { AuthProvider } from './AuthContext';
import AnaEkran from './AnaEkran';
import Login from './Login';
import KelimeEkle from './KelimeEkle';
import Oyun from './Oyun';
import Signup from './Signup';

const Stack = createStackNavigator();

const App = () => {
  return (
    <AuthProvider>
      <NavigationContainer>
        <Stack.Navigator initialRouteName="Login">
          <Stack.Screen name="Login" component={Login} />
          <Stack.Screen name="AnaEkran" component={AnaEkran} />
          <Stack.Screen name="KelimeEkle" component={KelimeEkle} />
          <Stack.Screen name="Oyun" component={Oyun} />
          <Stack.Screen name="Signup" component={Signup} /> 
        </Stack.Navigator>
      </NavigationContainer>
    </AuthProvider>
  );
};

export default App;
