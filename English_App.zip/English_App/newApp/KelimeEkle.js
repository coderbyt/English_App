import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet, ImageBackground, Text, Alert } from 'react-native';
import { getDatabase, ref, push, set, get } from 'firebase/database';

const db = getDatabase();

const KelimeEkle = ({ navigation }) => {
  const [kelime, setKelime] = useState('');
  const [anlam, setAnlam] = useState('');
  const [kategori, setKategori] = useState('');

  const handleKelimeEkle = async () => {
    // Boş giriş alanlarını kontrol et
    if (!kelime.trim() || !anlam.trim() || !kategori.trim()) {
      Alert.alert('Hata', 'Kelime, Anlam ve Kategori alanları boş bırakılamaz.');
      return;
    }

    try {
      const kategoriRef = ref(db, 'kategoriler');
      const snapshot = await get(kategoriRef);
      const kategoriler = snapshot.val();

      if (kategoriler && kategori in kategoriler) {
        // Kategori zaten mevcut, yeni kelimeyi bu kategoriye ekle
        const kelimeRef = ref(db, `kategoriler/${kategori}`);
        const newKelimeRef = push(kelimeRef);
        await set(newKelimeRef, {
          kelime: kelime,
          anlam: anlam,
        });
      } else {
        // Kategori yok, yeni kategori oluştur ve kelimeyi ekle
        await set(ref(db, `kategoriler/${kategori}`), true);
        const kelimeRef = ref(db, `kategoriler/${kategori}`);
        const newKelimeRef = push(kelimeRef);
        await set(newKelimeRef, {
          kelime: kelime,
          anlam: anlam,
        });
      }

      navigation.navigate('AnaEkran');
    } catch (error) {
      console.error('Kelime ekleme hatası:', error);
    }
  };

  return (
    <ImageBackground source={{ uri: 'https://images.pexels.com/photos/5428833/pexels-photo-5428833.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500' }} style={styles.background}>
      <View style={styles.container}>
        <Text style={styles.headerText}>Kelime Ekleyiniz !!!</Text>
        <TextInput
          style={styles.input}
          placeholder="Kelime"
          value={kelime}
          onChangeText={setKelime}
        />
        <TextInput
          style={styles.input}
          placeholder="Anlamı"
          value={anlam}
          onChangeText={setAnlam}
        />
        <TextInput
          style={styles.input}
          placeholder="Kategori"
          value={kategori}
          onChangeText={setKategori}
        />
        <Button title="Kelime Ekle" onPress={handleKelimeEkle} />
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: "cover",
    justifyContent: "center",
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerText: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 20,
    color: 'black',
  },
  input: {
    height: 40,
    width: '80%',
    marginVertical: 10,
    borderWidth: 1,
    borderColor: 'gray',
    paddingHorizontal: 10,
    backgroundColor: 'white',
  },
});

export default KelimeEkle;
