import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const SkorTablosu = ({ dogruSayisi, yanlisSayisi }) => {
  return (
    <View style={styles.container}>
      <Text style={[styles.text, { color: 'green' }]}>DOĞRU: {dogruSayisi} </Text>
      <Text style={[styles.text, { color: 'red' }]}>YANLIŞ: {yanlisSayisi} </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#DDDDDD',
    padding: 20,
    borderRadius: 10,
    margin: 10,
  },
  text: {
    fontSize: 18,
  },
});

export default SkorTablosu;
